<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('price_change_histories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->foreignId('purchase_id')->nullable()->constrained('purchases')->nullOnDelete(); // Faktur mana yang memicu perubahan
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete(); // Siapa yang input
            $table->integer('old_price'); // Harga modal sebelumnya
            $table->integer('new_price'); // Harga modal terbaru
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('price_change_histories');
    }
};
