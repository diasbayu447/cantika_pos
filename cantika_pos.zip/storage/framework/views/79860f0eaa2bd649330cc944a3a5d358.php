

<?php $__env->startSection('title', 'Log Aktivitas & Audit Trail'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show fw-bold" style="border-radius: 10px;" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger fw-bold" style="border-radius: 10px;">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($error); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card border-0 p-4 shadow-sm" style="border-radius: 15px; background: #fff;">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="fw-bold m-0" style="color: #333;">Audit Trail & Rekaman Log Sistem</h5>
            <small class="text-muted">Jejak audit operasional kasir, kulakan, otorisasi, dan riwayat pengeditan data.</small>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle" style="font-size: 13px;">
            <thead class="table-light">
                <tr>
                    <th width="15%">Waktu</th>
                    <th width="15%">Pengguna</th>
                    <th width="16%">Tindakan</th>
                    <th>Keterangan & Rincian Perubahan</th>
                    <th width="16%" class="text-center">Aksi Rollback</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $oldVals = is_array($log->old_values) ? $log->old_values : json_decode($log->old_values, true);
                    $newVals = is_array($log->new_values) ? $log->new_values : json_decode($log->new_values, true);
                ?>
                <tr>
                    <td class="text-muted"><?php echo e($log->created_at->format('d/m/Y H:i:s')); ?></td>
                    <td>
                        <strong><?php echo e($log->user->name ?? 'Sistem'); ?></strong><br>
                        <small class="text-muted font-monospace">(<?php echo e(strtoupper($log->user->role ?? '-')); ?>)</small>
                    </td>
                    <td>
                        <?php if(str_contains(strtolower($log->action), 'rollback')): ?>
                            <span class="badge bg-warning text-dark font-monospace">⏪ <?php echo e($log->action); ?></span>
                        <?php elseif(str_contains(strtolower($log->action), 'hapus') || str_contains(strtolower($log->action), 'kick')): ?>
                            <span class="badge bg-danger font-monospace">🛑 <?php echo e($log->action); ?></span>
                        <?php elseif(str_contains(strtolower($log->action), 'tambah') || str_contains(strtolower($log->action), 'kulakan')): ?>
                            <span class="badge bg-success font-monospace">✨ <?php echo e($log->action); ?></span>
                        <?php else: ?>
                            <span class="badge bg-secondary font-monospace"><?php echo e($log->action); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="text-dark fw-bold"><?php echo e($log->description ?? '-'); ?></span>

                        
                        <?php if(!empty($oldVals) && !empty($newVals)): ?>
                            <div class="mt-1 p-2 rounded bg-light border" style="font-size: 11.5px;">
                                <?php if(($oldVals['retail_price'] ?? null) != ($newVals['retail_price'] ?? null)): ?>
                                    <div>
                                        Harga Eceran: <del class="text-muted">Rp <?php echo e(number_format($oldVals['retail_price'] ?? 0, 0, ',', '.')); ?></del> 
                                        &rarr; <strong class="text-primary">Rp <?php echo e(number_format($newVals['retail_price'] ?? 0, 0, ',', '.')); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(($oldVals['cost_price'] ?? null) != ($newVals['cost_price'] ?? null)): ?>
                                    <div>
                                        Harga Modal (HPP): <del class="text-muted">Rp <?php echo e(number_format($oldVals['cost_price'] ?? 0, 0, ',', '.')); ?></del> 
                                        &rarr; <strong class="text-danger">Rp <?php echo e(number_format($newVals['cost_price'] ?? 0, 0, ',', '.')); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(($oldVals['wholesale_price'] ?? null) != ($newVals['wholesale_price'] ?? null)): ?>
                                    <div>
                                        Harga Grosir: <del class="text-muted">Rp <?php echo e(number_format($oldVals['wholesale_price'] ?? 0, 0, ',', '.')); ?></del> 
                                        &rarr; <strong class="text-success">Rp <?php echo e(number_format($newVals['wholesale_price'] ?? 0, 0, ',', '.')); ?></strong>
                                    </div>
                                <?php endif; ?>
                                <?php if(($oldVals['stock'] ?? null) != ($newVals['stock'] ?? null)): ?>
                                    <div>
                                        Stok: <del class="text-muted"><?php echo e($oldVals['stock'] ?? 0); ?></del> 
                                        &rarr; <strong><?php echo e($newVals['stock'] ?? 0); ?> pcs</strong>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td class="text-center text-nowrap">
                        <?php if(!empty($oldVals) && !$log->is_rolled_back): ?>
                            <form action="<?php echo e(route('activity_logs.rollback', $log->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-outline-warning fw-bold px-2 py-1 text-dark" 
                                        onclick="return confirm('Kembalikan data barang ini ke kondisi sebelum diedit?');"
                                        title="Kembalikan data lama" style="border-radius: 6px; font-size: 11.5px;">
                                    ⏪ Rollback Data
                                </button>
                            </form>
                        <?php elseif($log->is_rolled_back): ?>
                            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25" style="font-size: 11px;">✅ Sudah di-Undo</span>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center py-4 text-muted">Belum ada riwayat aktivitas tercatat.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end mt-3">
        <?php echo e($logs->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\cantika_pos\resources\views/activity_logs/index.blade.php ENDPATH**/ ?>