

<?php $__env->startSection('title', 'Laporan Penjualan & Laba'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<style>
    @media print {
        .no-print { display: none !important; }
        .card { border: none !important; box-shadow: none !important; }
        body { background-color: #fff !important; }
    }
</style>

<!-- Filter Periode & Tombol Cetak -->
<div class="card border-0 p-4 mb-4 no-print" style="border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
    <form action="<?php echo e(route('reports.index')); ?>" method="GET" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label text-muted small fw-bold">Dari Tanggal</label>
            <input type="date" name="start_date" class="form-control" value="<?php echo e($startDate); ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label text-muted small fw-bold">Sampai Tanggal</label>
            <input type="date" name="end_date" class="form-control" value="<?php echo e($endDate); ?>" required>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn fw-bold px-4 w-100" style="background-color: #f2a6b0; color: white; border-radius: 8px;">
                🔍 Terapkan Filter
            </button>
        </div>
        <div class="col-md-3 text-end">
            <button type="button" class="btn btn-outline-secondary px-3" onclick="window.print()" style="border-radius: 8px;">
                🖨️ Cetak Rekap (PDF)
            </button>
        </div>
    </form>
</div>

<!-- Kartu Ringkasan Metrik Finansial -->
<!-- Kartu Ringkasan Metrik Finansial & Laba Bersih -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 p-3 h-100 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #0d6efd !important;">
            <small class="text-muted fw-bold">TOTAL OMZET BERSIH</small>
            <h4 class="fw-bold mt-2 text-primary">Rp <?php echo e(number_format($totalNetSales, 0, ',', '.')); ?></h4>
            <small class="text-muted"><?php echo e(count($transactions)); ?> Transaksi Berhasil</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 p-3 h-100 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #198754 !important;">
            <small class="text-muted fw-bold">LABA KOTOR (GROSS PROFIT)</small>
            <h4 class="fw-bold mt-2 text-success">Rp <?php echo e(number_format($grossProfit, 0, ',', '.')); ?></h4>
            <small class="text-muted">Omzet dikurangi Modal HPP</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 p-3 h-100 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #17a2b8 !important;">
            <small class="text-muted fw-bold">LABA BERSIH RIIL (NET PROFIT)</small>
            <h4 class="fw-bold mt-2 <?php echo e($netProfit >= 0 ? 'text-success' : 'text-danger'); ?>">
                Rp <?php echo e(number_format($netProfit, 0, ',', '.')); ?>

            </h4>
            <small class="text-muted">Laba kotor dikurangi seluruh beban operasional</small>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 p-3 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #dc3545 !important;">
            <small class="text-muted fw-bold">TOTAL KAS KELUAR KASIR (PETTY CASH)</small>
            <h5 class="fw-bold text-danger mt-1">Rp <?php echo e(number_format($totalPettyCash, 0, ',', '.')); ?></h5>
            <small class="text-muted">Pengeluaran harian meja kasir</small>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 p-3 shadow-sm" style="border-radius: 12px; background: #fff; border-left: 4px solid #6c757d !important;">
            <small class="text-muted fw-bold">BIAYA OPERASIONAL TOKO (LISTRIK, GAJI, DLL)</small>
            <h5 class="fw-bold text-dark mt-1">Rp <?php echo e(number_format($totalOperationalExpense, 0, ',', '.')); ?></h5>
            <small class="text-muted">Beban operasional umum periode ini</small>
        </div>
    </div>
</div>

<!-- Rincian Aliran Kas & Potongan Diskon -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 p-3" style="border-radius: 12px; background-color: #fff;">
            <span class="text-muted small fw-bold d-block">PENERIMAAN KAS (TUNAI)</span>
            <h5 class="fw-bold text-dark mt-1">Rp <?php echo e(number_format($totalCash, 0, ',', '.')); ?></h5>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 p-3" style="border-radius: 12px; background-color: #fff;">
            <span class="text-muted small fw-bold d-block">PENERIMAAN NON-TUNAI (QRIS/TRF)</span>
            <h5 class="fw-bold text-info mt-1">Rp <?php echo e(number_format($totalNonCash, 0, ',', '.')); ?></h5>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 p-3" style="border-radius: 12px; background-color: #fff;">
            <span class="text-muted small fw-bold d-block">TOTAL POTONGAN DISKON/VOUCHER</span>
            <h5 class="fw-bold text-danger mt-1">-Rp <?php echo e(number_format($totalDiscount, 0, ',', '.')); ?></h5>
        </div>
    </div>
</div>

<!-- Tab Navigasi: Rincian Transaksi vs Rekap Shift -->
<div class="card border-0 p-4" style="border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
    <ul class="nav nav-pills mb-3 no-print" id="reportTab" role="tablist">
        <li class="nav-item">
            <button class="nav-link active btn-sm" id="trans-tab-btn" data-bs-toggle="pill" data-bs-target="#trans-tab" type="button">
                🧾 Rincian Transaksi Penjualan
            </button>
        </li>
        <li class="nav-item">
            <button class="nav-link btn-sm" id="shift-tab-btn" data-bs-toggle="pill" data-bs-target="#shift-tab" type="button">
                ⚖️ Rekap Shift & Selisih Kasir
            </button>
        </li>
    </ul>

    <div class="tab-content" id="reportTabContent">
        <!-- Tab 1: Tabel Transaksi -->
        <div class="tab-pane fade show active" id="trans-tab">
            <div class="table-responsive">
                <table id="transactionsTable" class="table table-hover align-middle" style="font-size: 13px; width: 100%;">
                    <thead class="table-light">
                        <tr>
                            <th>Waktu</th>
                            <th>No. Faktur</th>
                            <th>Kasir</th>
                            <th>Pelanggan</th>
                            <th>Metode</th>
                            <th>Diskon</th>
                            <th>Total Belanja</th>
                            <th class="no-print text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($trx->created_at->format('d/m/Y H:i')); ?></td>
                            <td class="fw-bold font-monospace"><?php echo e($trx->invoice_number); ?></td>
                            <td><?php echo e($trx->user->name ?? '-'); ?></td>
                            <td><?php echo e($trx->customer->name ?? 'Pelanggan Umum'); ?></td>
                            <td>
                                <span class="badge <?php echo e($trx->payment_method === 'cash' ? 'bg-success' : 'bg-info text-dark'); ?>">
                                    <?php echo e(strtoupper($trx->payment_method)); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($trx->discount_amount > 0): ?>
                                    <span class="text-danger">-Rp <?php echo e(number_format($trx->discount_amount, 0, ',', '.')); ?></span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold text-dark">Rp <?php echo e(number_format($trx->total_amount, 0, ',', '.')); ?></td>
                            <td class="no-print text-center">
                                <a href="<?php echo e(route('pos.receipt', $trx->id)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary px-2 py-1" title="Lihat Struk">
                                    🖨️ Struk
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tab 2: Tabel Shift Kasir & Selisih Laci -->
        <div class="tab-pane fade" id="shift-tab">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle" style="font-size: 13px; width: 100%;">
                    <thead class="table-light">
                        <tr>
                            <th>Kasir Bertugas</th>
                            <th>Buka Shift</th>
                            <th>Tutup Shift</th>
                            <th>Modal Awal</th>
                            <th>Uang Sistem</th>
                            <th>Uang Fisik Dihitung</th>
                            <th class="text-center">Selisih</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-bold text-dark"><?php echo e($shift->user->name ?? '-'); ?></td>
                            <td><?php echo e($shift->opened_at ? $shift->opened_at->format('d/m H:i') : '-'); ?></td>
                            <td><?php echo e($shift->closed_at ? $shift->closed_at->format('d/m H:i') : 'Masih Buka'); ?></td>
                            <td>Rp <?php echo e(number_format($shift->start_cash, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($shift->end_cash_system, 0, ',', '.')); ?></td>
                            <td class="fw-bold">
                                <?php echo e($shift->status === 'closed' ? 'Rp ' . number_format($shift->end_cash_actual, 0, ',', '.') : '-'); ?>

                            </td>
                            <td class="text-center">
                                <?php if($shift->status === 'closed'): ?>
                                    <?php if($shift->difference === 0): ?>
                                        <span class="badge bg-success">Pas (Rp 0)</span>
                                    <?php elseif($shift->difference < 0): ?>
                                        <span class="badge bg-danger">Kurang Rp <?php echo e(number_format(abs($shift->difference), 0, ',', '.')); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Lebih +Rp <?php echo e(number_format($shift->difference, 0, ',', '.')); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?php echo e($shift->status === 'open' ? 'bg-primary' : 'bg-secondary'); ?>">
                                    <?php echo e(strtoupper($shift->status)); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-3 text-muted">Tidak ada rekaman shift pada rentang tanggal ini.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#transactionsTable').DataTable({
            order: [[0, 'desc']],
            language: {
                search: "Cari Faktur/Kasir:",
                lengthMenu: "Tampil _MENU_",
                info: "Menampilkan _START_ - _END_ dari _TOTAL_ transaksi"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\cantika_pos\resources\views/reports/index.blade.php ENDPATH**/ ?>